for f in ./*; do g="${f##*red-}"
	echo "Redundancy: ${g%%.edgelist} --- Number of redundant edges: $(comm -12 <(grep "^0" $f | awk '{print $2, $3}' | sort) <(grep "^1" $f | awk '{print $2, $3}' | sort) | wc -l)"
done | less
